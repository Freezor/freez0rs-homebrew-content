Hooks.once("init", function () {
    CONFIG.DND5E.spellSchools['sht'] = 'Zerbersten';
});